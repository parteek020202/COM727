To run the chatbot, upload "Medical_Chatbot.ipynb" and "intents.json" on google colab
Then run all cells in file "Medical_Chatbot.ipynb"
you can input your query and get answers
type "exit" to stop the program
